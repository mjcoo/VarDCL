Environment

Python 3.10

CUDA 12.6



Code

Encoder Methods of TransFormer Block

KAN.py: Methods of KAN-Liner Module for Defined Classifier



Usage

Environment

conda create -name <env> python=3.10

conda activate <env>



Dependences

conda install --yes --file requirements.txt

training

1.python train.py

prediction of mutation effects

2\.python test.py 

